from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import info, history, regist, cart
from django.shortcuts import redirect


def func(request):
    if request.method=="POST":
          fname=request.POST['fname']
          lname=request.POST['lname']
          age=request.POST['age']
          add=request.POST['add']
          email=request.POST['email']
          passw=request.POST['passw']
          cpassw=request.POST['cpassw']
          nw=regist(fname=fname,lname=lname,add=add,age=age,email=email,passw=passw,cpassw=cpassw)
          nw.save()
    return render(request, 'main.html')

def ear(request):
    getu=info.objects.filter(pid__gt=6, pid__lt=8)
    setu=info.objects.filter(pid__gt=7, pid__lt=9)
    metu=info.objects.filter(pid__gt=8, pid__lt=10)
    context = {
        'shoo': getu,
        'shoe': setu,
        'shou': metu,
    }
    return render(request, 'earphones.html', context)

def spe(request):
    getu=info.objects.filter(pid__gt=3, pid__lt=5)
    setu=info.objects.filter(pid__gt=4, pid__lt=6)
    metu=info.objects.filter(pid__gt=5, pid__lt=7)
    context = {
        'shoo': getu,
        'shoe': setu,
        'shou': metu,
    }
    return render(request, 'speaker.html', context)

def mob(request):
    getu=info.objects.filter(pid__gt=0, pid__lt=2)
    setu=info.objects.filter(pid__gt=1, pid__lt=3)
    metu=info.objects.filter(pid__gt=2, pid__lt=4)
    context = {
        'shoo': getu,
        'shoe': setu,
        'shou': metu,
    }
    return render(request, 'mobile.html', context)

def wspe(request):
     getu=info.objects.filter(pid__gt=4, pid__lt=6)
     return render(request, 'wspe.html', {'shoo':getu})

def jbl(request):
     getu=info.objects.filter(pid__gt=3, pid__lt=5)
     return render(request, 'jbl.html', {'shoo':getu})

def tooth(request):
     getu=info.objects.filter(pid__gt=5, pid__lt=7)
     return render(request, 'tooth.html', {'shoo':getu})

def iphone(request):
     getu=info.objects.filter(pid__gt=1, pid__lt=3)
     return render(request, 'iphone.html', {'shoo':getu})

def plus(request):
     getu=info.objects.filter(pid__gt=2, pid__lt=4)
     return render(request, 'plus.html', {'shoo':getu})

def sung(request):
     getu=info.objects.filter(pid__gt=0, pid__lt=2)
     return render(request, 'sung.html', {'shoo':getu})

def add(request):
     return render(request, 'add.html')

def prod(request, image_id):
     if info:
          image=get_object_or_404(info, id=image_id)
     return render(request, 'prod.html', {'image': image})

def acc(request):
     shoo=regist.objects.latest('datt')
     return render(request, 'acc.html', {'shoo':shoo})

def cart(request):
     getu=history.objects.filter(oid__gt=0, oid__lt=2)
     setu=history.objects.filter(oid__gt=1, oid__lt=3)
     context = {
        'shoo': getu,
        'shou': setu,
    }
#     if request.method=="POST":
#          title = request.POST['title']
#          image = request.POST['image']
#          price = request.POST['price']
#          print(title, price)
#          newitem=history(title=title, price=price, image=image)
#          newitem.save()
     return render(request, 'cart.html', context)
   
def hist(request):
     getu=history.objects.filter(oid__gt=0, oid__lt=2)
     setu=history.objects.filter(oid__gt=1, oid__lt=3)
     context = {
        'shoo': getu,
        'shou': setu,
    }
     return render(request, 'hist.html', context)

def earbud(request):
     getu=info.objects.filter(pid__gt=6, pid__lt=8)
     return render(request, 'earbud.html', {'shoo':getu})

def charger(request):
     getu=info.objects.filter(pid__gt=9, pid__lt=11)
     return render(request, 'charger.html', {'shoo':getu})

def cover(request):
     getu=info.objects.filter(pid__gt=10, pid__lt=12)
     return render(request, 'cover.html', {'shoo':getu})

def cable(request):
     getu=info.objects.filter(pid__gt=11, pid__lt=13)
     return render(request, 'cover.html', {'shoo':getu})