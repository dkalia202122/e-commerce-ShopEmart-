from django.contrib import admin
from .models import info, regist, cart, history

class infu(admin.ModelAdmin):
    list_display=['pid','title','price','image','ratings','avail', 'datt']

admin.site.register(info, infu)

class carte(admin.ModelAdmin):
    list_display=['titleg','pric','imag']

admin.site.register(cart, carte)

class histury(admin.ModelAdmin):
    list_display=['oid','title','price','image']

admin.site.register(history, histury)

class regi(admin.ModelAdmin):
    list_display=['fname','lname','age','add','email','passw','cpassw','datt']

admin.site.register(regist, regi)