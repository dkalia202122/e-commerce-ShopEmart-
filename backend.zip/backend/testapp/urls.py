from django.contrib import admin
from django.urls import path, include
from testapp import views

urlpatterns=[
    path('main', views.func, name='main'),
    path('earphones', views.ear, name='earphones'),
    path('mobile', views.mob, name='mobile'),
    path('speaker', views.spe, name='speaker'),
    path('jbl', views.jbl, name='jbl'),
    path('tooth', views.tooth),
    path('wspe', views.wspe),
    path('iphone', views.iphone),
    path('plus', views.plus),
    path('sung', views.sung),
    path('add', views.add),
    path('acc', views.acc),
    path('cart', views.cart, name='cart'),
    path('hist.html', views.hist, name='hist'),
    path('image/<int:image_id>/cart', views.cart, name='cart'),
    path('earbud', views.earbud),
    path('charger', views.charger),
    path('cover', views.cover),
    path('cable', views.cable),
#    path('', views.abb, name='abcd'),
    path('image/<int:image_id>/', views.prod, name='prod')
]
