from django.db import models
from django.utils import timezone

class info(models.Model):
    pid=models.IntegerField(default=1)
    title=models.TextField(max_length=1000)
    image=models.ImageField(upload_to='infouploads/')
    price=models.TextField(max_length=100)
    ratings=models.CharField(max_length=20)
    avail=models.CharField(max_length=20)
    datt=models.DateTimeField(auto_now_add=True)

    def get_absolute_url(self):
        return f'/image/{self.id}/'

class regist(models.Model):
    fname=models.CharField(max_length=15)
    lname=models.CharField(max_length=15)
    age=models.IntegerField()
    email=models.EmailField()
    add=models.CharField(max_length=100)
    passw=models.CharField(max_length=20)
    cpassw=models.CharField(max_length=20)
    datt=models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.fname

class cart(models.Model):
    titleg=models.TextField(max_length=100)
    imag=models.ImageField(upload_to='cartuploads/')
    pric=models.TextField(max_length=100)
    def __str__(self):
        return self.titleg
    

class history(models.Model):
    oid=models.IntegerField(unique=True, default=1)
    title=models.TextField(max_length=100)
    image=models.ImageField(upload_to='histuploads/')
    price=models.TextField(max_length=100)
    def save(self, *args, **kwargs):
        if not self.id:
            max_order_id = history.objects.aggregate(models.Max('oid'))['oid__max']
            self.oid = 1 if max_order_id is None else max_order_id + 1
        super(history, self).save(*args, **kwargs)
    def __str__(self):
        return f"Order {self.oid}"
